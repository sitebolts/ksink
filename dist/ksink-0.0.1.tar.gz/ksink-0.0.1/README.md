# ksink
Miscellaneous Python helper functions

----------
[![GitHub license](https://img.shields.io/badge/license-MIT-blue.svg)](https://raw.githubusercontent.com/circleci/circleci-docs/master/LICENSE)
[![CircleCI Build Status](https://circleci.com/gh/sitebolts/ksink.svg?style=shield)](https://app.circleci.com/pipelines/github/sitebolts/ksink)
[![AppVeyor](https://ci.appveyor.com/api/projects/status/github/sitebolts/ksink?branch=main&svg=true)](https://ci.appveyor.com/project/sitebolts/ksink)
